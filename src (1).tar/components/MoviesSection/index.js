import {Component} from 'react'
import Loader from 'react-loader-spinner'
import {
  AiFillLinkedin,
  AiFillTwitterCircle,
  AiFillFacebook,
} from 'react-icons/ai'
import MovieItem from '../MovieItem'

import './index.css'

class Movies extends Component {
  state = {moviesList: [], isLoading: true}

  componentDidMount() {
    this.getMovies()
  }

  getMovies = async () => {
    const response = await fetch(' https://api.tvmaze.com/search/shows?q=all')
    if (response.ok) {
      const data = await response.json()
      this.setState({moviesList: data})
      this.setState(old => ({
        isLoading: !old.isLoading,
      }))
    }
  }

  render() {
    const {isLoading, moviesList} = this.state
    if (isLoading) {
      return (
        <div className="loader-cont">
          <Loader type="ThreeDots" />
        </div>
      )
    }
    return (
      <div className="bg">
        <div className="banner">
          <img
            src="https://img.freepik.com/premium-vector/cinema-logo_23-2147503279.jpg"
            alt="movie"
            className="movie-logo"
          />

          <h1 className="heading">MOVIE THEATRE</h1>
          <p className="subHead">Book Your Show</p>
        </div>
        <ul className="list-cont">
          {moviesList.map(eachItem => (
            <MovieItem movieItem={eachItem} key={eachItem.show.id} />
          ))}
        </ul>
        <div className="footer">
          <h3>Web Designers About</h3>
          <h4>NxtWave || QuedB</h4>
          <div className="social">
            <AiFillFacebook className="ioc" />
            <AiFillTwitterCircle className="ioc" />
            <AiFillLinkedin className="ioc" />
          </div>
        </div>
      </div>
    )
  }
}

export default Movies
