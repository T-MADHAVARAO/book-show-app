import {Component} from 'react'
import {Link} from 'react-router-dom'
import Popup from 'reactjs-popup'
import 'reactjs-popup/dist/index.css'

import './index.css'

class MovieDetails extends Component {
  state = {movieData: {}, isLoading: true}

  componentDidMount() {
    this.getMovieData()
  }

  async getMovieData() {
    const {match} = this.props
    const {params} = match
    const {id} = params

    try {
      const response = await fetch(`https://api.tvmaze.com/shows/${id}`)
      if (response.ok) {
        const data = await response.json()

        this.setState({movieData: data})
        this.setState(old => ({isLoading: !old.isLoading}))
      } else {
        console.error('Failed to fetch movie data')
      }
    } catch (error) {
      console.error('An error occurred:', error)
    }
  }

  render() {
    const {movieData, isLoading} = this.state

    const imageUrl =
      'https://png.pngtree.com/png-vector/20190816/ourmid/pngtree-film-logo-design-template-vector-isolated-illustration-png-image_1693431.jpg' // Default image URL

    if (isLoading) {
      return (
        <div className="loader-cont">
          <p>...Loading</p>
        </div>
      )
    }

    return (
      <div className="movie-bg">
        <h1>{movieData.name}</h1>
        <img src={imageUrl} alt="movie-img" className="movie-Img" />
        <p>{movieData.summary}</p>
        <div className="details">
          <p>Language : {movieData.language}</p>
          <p>Type : {movieData.type}</p>
          <a href={movieData.officialSite}>Official Site</a>
          <a href={movieData.url}>More About Movie</a>
        </div>
        <div className="btn-cont">
          <Link to="/">
            <button className="trigger-button" type="button">
              Home
            </button>
          </Link>
          <div className="popup-container">
            <Popup
              modal
              trigger={
                <button type="button" className="trigger-button">
                  Book Show
                </button>
              }
            >
              {close => (
                <>
                  <div>
                    <form>
                      <p>Name</p>
                      <input type="text" />
                      <p>Date</p>
                      <input type="date" />
                      <p>No of Bookings</p>
                      <input type="text" />
                    </form>

                    <p>Booking Opened Soon.Thank You For Visiting.</p>
                  </div>
                  <button
                    type="button"
                    className="trigger-button"
                    onClick={() => close()}
                  >
                    Close
                  </button>
                </>
              )}
            </Popup>
          </div>
        </div>
      </div>
    )
  }
}

export default MovieDetails
