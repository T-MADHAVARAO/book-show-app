import {Link} from 'react-router-dom'
import {v4 as uuidv4} from 'uuid'

import {AiTwotoneStar} from 'react-icons/ai'
import './index.css'

const MovieItem = props => {
  const {movieItem} = props
  const {show} = movieItem
  let imageUrl = null
  if (show.image !== null) {
    imageUrl = show.image.original
  } else {
    imageUrl =
      'https://png.pngtree.com/png-vector/20190816/ourmid/pngtree-film-logo-design-template-vector-isolated-illustration-png-image_1693431.jpg'
  }

  return (
    <div className="movie-card">
      <h1 className="movie-name">{show.name.toUpperCase()}</h1>
      <img src={imageUrl} alt="thumbnail" className="thumbnail" />
      <ul className="genres">
        genre:{' '}
        {show.genres.map(each => (
          <li className="genre-item" key={uuidv4()}>
            {each}
          </li>
        ))}
      </ul>
      <div className="rating-language">
        <p>{show.language}</p>
        <div className="rating">
          <AiTwotoneStar />

          <p>{show.rating.average > 0 ? show.rating.average : 'NA'}</p>
        </div>
      </div>
      <Link to={`/movie/${show.id}`}>
        <button className="more-btn" type="button">
          Show More
        </button>
      </Link>
    </div>
  )
}

export default MovieItem
